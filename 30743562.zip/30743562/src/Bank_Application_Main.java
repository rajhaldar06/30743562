import java.util.*;

public class Bank_Application_Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final BankingSystem bankingSystem = new BankingSystem();
    public static void main(String[] args) {

        System.out.println("Hello and welcome!");
        while (true) {
            System.out.println("Banking System Menu:");
            System.out.println("1. Add Account");
            System.out.println("2. Remove Account");
            System.out.println("3. Update Account");
            System.out.println("4. Deposit Funds");
            System.out.println("5. Withdraw Funds");
            System.out.println("6. Transfer Funds");
            System.out.println("7. Print Account Details");
            System.out.println("8. Print Transactions");
            System.out.println("9. Exit");
            System.out.print("enter here : ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addAccount();
                    break;
                case 2:
                    removeAccount();
                    break;
                case 3:
                    updateAccount();
                    break;
                case 4:
                    depositFunds();
                    break;
                case 5:
                    withdrawFunds();
                    break;
                case 6:
                    transferFunds();
                    break;
                case 7:
                    bankingSystem.showAccountDetails();
                    break;
                case 8:
                    bankingSystem.showTransactions();
                    break;
                case 9:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void addAccount() {
        try{
            System.out.print("Enter account ID: ");

            int id = scanner.nextInt();
            System.out.print("Enter customer ID: ");
            int customerId = scanner.nextInt();
            System.out.print("Enter balance: ");
            double balance = scanner.nextDouble();
            System.out.print("Enter account type: ");
            String accountType = scanner.next();

            CustomerAccount customerAccount = new CustomerAccount(id, customerId, balance, accountType);
            bankingSystem.addcustomerAccount(customerAccount);
            System.out.println(customerAccount);
        }
        catch(InputMismatchException e){
            System.out.println("Please give valid details type...");
        }

    }

    private static void removeAccount(){
        try{
            System.out.print("Enter account ID to remove: ");
            int id = scanner.nextInt();
            bankingSystem.removecustomerAccount(id);
            System.out.println("Removed Successfully");
        }catch(InputMismatchException e){
            System.out.println("Please give valid details type...");
        }

    }
    private static void updateAccount(){
        try{
            System.out.print("Enter account ID to update: ");

            int id = scanner.nextInt();
            System.out.print("Enter new balance: ");
            double balance = scanner.nextDouble();
            scanner.nextLine();
            System.out.print("Enter new account type: ");
            String accountType = scanner.nextLine();

            CustomerAccount updatedAccount = new CustomerAccount(id, -1, balance, accountType);
            bankingSystem.updatecustomerAccount(id, updatedAccount);
            System.out.println("Account updated.");
        }catch(InputMismatchException e){
            System.out.println("Please give valid details type...");
        }

    }
    private static void depositFunds(){
        try{
            System.out.println("Enter account ID to deposit ");

            int id = scanner.nextInt();
            System.out.println("Enter amount");
            double amount = scanner.nextDouble();

            bankingSystem.depositFunds(id,amount);
        }catch(InputMismatchException e){
            System.out.println("Please give valid details type...");
        }

    }
    private static void withdrawFunds(){
        try{
            System.out.print("Enter account ID to deposit ");

            int id = scanner.nextInt();
            System.out.println("Enter amount");
            double amount = scanner.nextDouble();

            bankingSystem.withdrawFunds(id,amount);
        }catch(InputMismatchException e){
            System.out.println("Please give valid details type...");
        }

    }
    private static void transferFunds(){
        try{
            System.out.print("Enter account ID for transfer from :");

            int fid = scanner.nextInt();
            System.out.print("Enter account ID for transfer to :");
            int tid = scanner.nextInt();
            System.out.println("Enter amount");
            double amount = scanner.nextDouble();

            bankingSystem.transferFunds(tid,fid,amount);
        }catch(InputMismatchException e){
            System.out.println("Please give valid details type...");
        }

    }
}
