public class CustomerAccount {
    private int id;
    private int customerId;
    private double balance;
    private String accountType;

    public CustomerAccount(int id, int customerId, double balance, String accountType){
        this.id = id;
        this.customerId = customerId;
        this.balance = balance;
        this.accountType = accountType;
    }
    public int getById(){
        return id;
    }
    public void setById(int id){
        this.id = id;
    }
    public int getCustomerId(){
        return customerId;
    }
    public void setCustomerId(){
        this.customerId = customerId;
    }
    public double getBalance(){
        return balance;
    }
    public void setBalance(double balance){
        this.balance = balance;
    }
    public String getAccountType(){
        return accountType;
    }
    public void setAccountType(String accountType){
        this.accountType = accountType;
    }
    @Override
    public String toString() {
        return "Account{Id=" + id + ", CustomerId=" + customerId + ", Balance=" + balance + ", AccountType='" + accountType + "'}";
    }
}
