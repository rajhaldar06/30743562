import java.sql.SQLOutput;
import java.util.*;


public class BankingSystem {
    private HashMap<Integer,CustomerAccount> customerAccountHashMap;
    private ArrayList<Transaction> transactionArrayList;
    private int transCounter = 1;

    public BankingSystem(){
        customerAccountHashMap = new HashMap<>();
        transactionArrayList = new ArrayList<>();
    }


    public void addcustomerAccount(CustomerAccount customerAccount){
        if (customerAccount != null && !customerAccountHashMap.containsKey(customerAccount.getById())){
            customerAccountHashMap.put(customerAccount.getById(),customerAccount);
        }
        System.out.println(customerAccountHashMap.size());
    }

    public void removecustomerAccount(int accountId){
        if(customerAccountHashMap.containsKey(accountId)){
            customerAccountHashMap.remove(accountId);
        }
        else{
            System.out.println("Account id is invalid");
        }
    }

    public void updatecustomerAccount(int accountId,CustomerAccount updateCustomerAccount){
        if(customerAccountHashMap.containsKey(accountId)){
            customerAccountHashMap.put(accountId,updateCustomerAccount);
        }
        else{
            System.out.println("Account id is invalid");
        }
    }

    public void depositFunds(int accountId,double amount){
        if(customerAccountHashMap.containsKey(accountId)){
            CustomerAccount customerAccount = customerAccountHashMap.get(accountId);
            customerAccount.setBalance(customerAccount.getBalance() + amount);
            addTransaction(accountId,"Deposit",amount);
        }
        else{
            System.out.println("Account id is invalid");
        }

    }

    public void withdrawFunds(int accountId,double amount){
        if(customerAccountHashMap.containsKey(accountId)){
            CustomerAccount customerAccount = customerAccountHashMap.get(accountId);
            if(customerAccount.getBalance() >= amount){
                customerAccount.setBalance(customerAccount.getBalance() - amount);
                addTransaction(accountId,"Withdrawl",amount);
            }
            else{
                System.out.println("Balance is not Sufficient");
            }
        }
        else{
            System.out.println("Account id is not valid");
        }
    }

    public void transferFunds(int toaccountId,int fromaccountId,double amount){
        if(customerAccountHashMap.containsKey(toaccountId) && customerAccountHashMap.containsKey(fromaccountId)){
            CustomerAccount toCustomerAccount = customerAccountHashMap.get(toaccountId);
            CustomerAccount fromCustomerAccount = customerAccountHashMap.get(fromaccountId);
            if(fromCustomerAccount.getBalance() >= amount){
                fromCustomerAccount.setBalance(fromCustomerAccount.getBalance() - amount);
                toCustomerAccount.setBalance(toCustomerAccount.getBalance() + amount);
                addTransaction(fromaccountId,"transfer",amount);
                addTransaction(toaccountId,"transfer",amount);
            }
            else{
                System.out.println("Insufficient balance");
            }
        }
        else{
            System.out.println("invalid account id's");
        }
    }

    public void addTransaction(int accountId,String transactionType,double amount){
        Transaction transaction = new Transaction(transCounter++,accountId,transactionType,amount,new Date());
        transactionArrayList.add(transaction);
    }
    public void showAccountDetails(){
        for(CustomerAccount customerAccount : customerAccountHashMap.values()){
            System.out.println(customerAccount);
        }

    }
    public void showTransactions(){
        for(Transaction transaction : transactionArrayList){
            System.out.println(transaction);
        }
    }
}
